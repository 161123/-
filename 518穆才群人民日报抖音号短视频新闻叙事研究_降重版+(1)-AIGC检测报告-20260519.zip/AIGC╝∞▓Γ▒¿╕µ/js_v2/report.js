var reportLock = true;
var reportSimilarity = "2.2%";
var reportUrl = "https://report.paperyy.com/20260519/2-1f4e56e8-a443-4260-a266-94e8867670c5/contrast.html?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1779725815&Signature=hrMx%2Bla1SpLIuvlP58S5zvkuFb4%3D";
var zipReportUrl = "https://report.paperyy.com/20260519/2-67e0800cb33545078bae2ffddf13ee3c-aigc/report.zip?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1779725815&Signature=EfLi3uEaV%2Bbv7wiOwZLeCT6BxbY%3D";
